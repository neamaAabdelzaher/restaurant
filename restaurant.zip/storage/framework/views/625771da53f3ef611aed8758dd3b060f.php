
<?php $__env->startSection('content'); ?>


<div class="container">
    <div class="row">
        <div class="col-md-8">
          <div class="card">
            <div class="card-header text-center bg-success text-light">Card</div>
         <div class="card-body">
            <table class="table">
                <thead>
                    <tr>
                      <th>Name</th>
                      <th>Price</th>
                      <th>Image</th>
                      
      
                       
                   
                    </tr>
                 </thead>
                 <tbody>
                  <tr>
                    
                         
                     <td><?php echo e($meal->name); ?></td>
                     <td><?php echo e($meal->price); ?></td>
                     <td><img src="<?php echo e(asset('assets/dashboard/images/'.$meal->image)); ?>" class="img-thumbnail" width="80"  alt="<?php echo e($meal->name); ?>">
                     </td>
                    
      
                    
                  </tr>
                 
      
                 </tbody>
            </table>
         </div>
          </div>
        </div>
        <div class="col-md-8" ></div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\restaurant\resources\views/cart.blade.php ENDPATH**/ ?>