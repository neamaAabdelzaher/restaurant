

<?php $__env->startSection('content'); ?>

<div class="col-md-12">
    <div class="white_shd full margin_bottom_30">
      <div class="card">
         <div class="card-header text-center bg-success text-light"> your orders</div>
       <div class="table_section padding_infor_info">
          <div class="table-responsive-sm card-body">
        <table class="table ">
           <thead>
              <tr>
                <th>Name</th>
                <th>phone</th>
                <th>email</th>
                <th>date</th>
                <th>time</th>
                <th>meal name</th>
                <th>meal price</th>
                <th>quantity</th>
                <th>Total Price</th>
                <th>address</th>
                <th>status</th>

                 
             
              </tr>
           </thead>
           <tbody>
           
               
            <tr>
               <?php if($orders->count()>0): ?>
               <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              
               <td><?php echo e($order->user->name); ?></td>
               <td><?php echo e($order->phone); ?></td>
               <td><?php echo e($order->user->email); ?></td>
               <td><?php echo e($order->date); ?></td>
               <td><?php echo e($order->time); ?></td>
               <td><?php echo e($order->meal->name); ?></td>
               <td><?php echo e($order->meal->price); ?></td>
               <td><?php echo e($order->quantity); ?></td>
               <td><?php echo e($order->meal->price*$order->quantity); ?></td>
               <td><?php echo e($order->address); ?></td>
               <td class="<?php if($order->status=="refuse"): ?> text-light bg-danger <?php elseif($order->status=="accept"): ?> text-light bg-success <?php elseif($order->status=="finished"): ?> text-light bg-info <?php elseif($order->status=="waiting"): ?> text-light bg-dark <?php endif; ?>"> <?php echo e($order->status); ?></td>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
               <?php else: ?>
              <td colspan="11" class="text-center text-info fs-5">No Orders</td>
            </tr>
           
            <?php endif; ?>

           </tbody>
        </table>
       </div>
    </div>
 </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\restaurant\resources\views/orders/show.blade.php ENDPATH**/ ?>