<div class="col-12 mb-2">
    <?php if(session('success')): ?>
             <div class="alert alert-success text-center"><?php echo e(session('success')); ?></div>
             <?php endif; ?>
    </div><?php /**PATH C:\xampp\htdocs\restaurant\resources\views/includes/message.blade.php ENDPATH**/ ?>