
<?php $__env->startSection('title','Categories'); ?>
<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

  <!-- table section -->
  <div class="col-md-12">
    <div class="white_shd full margin_bottom_30">
       <div class="full graph_head">
          <div class="heading1 margin_0">
            <h2>meals categories</h2>
          </div>
       </div>
       <div class="table_section padding_infor_info">
        <?php echo $__env->make('includes.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <div class="table-responsive-sm">
             <table class="table">
                <thead>
                   <tr>
                    
                    <th>#</th>
                    <th>Category Name</th>
                    <th>Edit</th>
                    <th>Delete</th>
                    
                   </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      
                  
                   <tr>
                      <td><?php echo e($key=$key+1); ?></td>
                      <td><?php echo e($category->category_name); ?></td>
                      <td>
                        <a class="btn btn-success" href="<?php echo e(route('dashboard.categories.edit',$category->id)); ?>" data-toggle="tooltip" data-placement="left" title="" data-original-title="Left">Edit</a>
                      </td>
                      <td>
                        <a class="btn btn-danger" id="delete" href="<?php echo e(route('dashboard.categories.delete',$category->id)); ?>" data-toggle="tooltip" data-placement="left" title="" data-original-title="Left">Delete</a>
                      </td>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </tr>
                
                </tbody>
             </table>
          </div>
       </div>
    </div>
 </div>
 <!-- table section -->

   
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.parent', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\restaurant\resources\views/Dashboard/categories/index.blade.php ENDPATH**/ ?>