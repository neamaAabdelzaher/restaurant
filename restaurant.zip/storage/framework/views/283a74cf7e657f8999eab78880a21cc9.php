
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header text-center bg-success text-light">
                        <h5>Filter</h5>
                        
                      </div>
                      <div class="card-body">
                          <a class="btn border border-secondary mb-2 justify-content-end " href="<?php echo e(route('visitorPage')); ?>">All Meals</a>
                          <form id="myForm" action="<?php echo e(route('filter')); ?>" method="post">
                              <?php echo csrf_field(); ?>
                              <div class="form-group">
                                  <label class="mb-2" for="cat_id">By Category:</label>
                                 
                                  <div class="controls">
                                      <select id="mySelect"  name="category_id"  id="cat_id" class="form-group p-2" aria-label="Default select example">
                                          <option disabled selected>Select Category</option>
                                          <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                              <option value="<?php echo e($category->id); ?>" >
                                                  <?php echo e($category->category_name); ?></option>
                                              
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                      </select>
                                  </div>
                              </div>
                      </form>
                      </div>


                </div>
                <?php if(Auth::check()): ?>
                <div class="card mt-5">
                    <div class="card-header text-center bg-success text-light">
                      <h5>Your orders</h5>
                      
                    </div>
                    <div class="card-body ">
                        <a class="btn border border-secondary mb-2 justify-content-end " href="<?php echo e(route('restaurant.show')); ?>">show orders</a>
                     
                    </div>


                </div>
                <?php endif; ?>
            </div>
            
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header text-center bg-success text-light">
                    
                        <?php if(isset($catName)): ?>
                        <h5> <?php echo e($catName); ?></h5>
                    <?php endif; ?>
                    <h5> meals Numbers (<?php echo e(count($meals)); ?>)</h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <?php $__empty_1 = true; $__currentLoopData = $meals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            
                            <div class="col-md-4 text-center mt-2 p-2" style="border: 1px solid rgb(204, 208, 216)">
                            <img src="<?php echo e(asset('assets/dashboard/images/'.$meal->image)); ?>" class="img-thumbnail w-100"  alt="<?php echo e($meal->name); ?>">
                                <strong><?php echo e($meal->name); ?></strong>
                                <p><?php echo e($meal->description); ?></p>
                                <div class="form-group text-center">
                                    <a href="<?php echo e(route('restaurant.meal-details',$meal->id)); ?>" class="btn btn-success">Order Now</a>
                                   </div>
                            </div>
                            
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                           <p class="text-center fs-3 ">No Meals Avilable</p>
                            <?php endif; ?>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<script>
document.getElementById('mySelect').addEventListener('change', function() {
    document.getElementById('myForm').submit();
});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\restaurant\resources\views/visitor-page.blade.php ENDPATH**/ ?>