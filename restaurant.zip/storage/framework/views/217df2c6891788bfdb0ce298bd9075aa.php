
<?php $__env->startSection('title','Meals'); ?> 
<?php $__env->startSection('content'); ?>

<div class="col-md-12">
   <div class="white_shd full margin_bottom_30">
      <div class="full graph_head">
         <div class="heading1 margin_0">
            <h2>Meals</h2>
         </div>
      </div>
      <div class="table_section padding_infor_info">
         <div class="table-responsive-sm">
       <table class="table">
          <thead>
             <tr>
             
                <th>meal name</th>
                <th>meal description</th>
                <th>price</th>
                <th>Category</th>
                <th>Image</th>
                <th>Edit</th>
                <th>Delete</th>
                
                
            
             </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $meals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <tr>
                
                <td><?php echo e($meal->name); ?></td>
                <td><?php echo e($meal->description); ?></td>
                <td><?php echo e($meal->price); ?></td>
                <td><?php echo e($meal->category->category_name); ?></td>
                <td><img src="<?php echo e(asset('assets/dashboard/images/'.$meal->image)); ?>" width="80" alt="<?php echo e($meal->name); ?>"> </td>
                <td>
                  <a href="<?php echo e(route('dashboard.meals.edit',$meal->id)); ?>" >
                  <img src="<?php echo e(asset('assets/dashboard/images/edit.png')); ?>" alt="Edit"> </a>
              </td>
              <td>
                  <a href="<?php echo e(route('dashboard.meals.delete',$meal->id)); ?>" >
                  <img src="<?php echo e(asset('assets/dashboard/images/delete.png')); ?>" alt="Delete"></a>
              </td>
             </tr>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
       </table>
      </div>
   </div>
</div>

<div class="row">
   <div class="col-12">
     <div class="pagination">
       <?php echo e($meals->links()); ?>

     </div>
   </div>
 </div>
</div>
 
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.parent', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\restaurant\resources\views/Dashboard/meals/index.blade.php ENDPATH**/ ?>