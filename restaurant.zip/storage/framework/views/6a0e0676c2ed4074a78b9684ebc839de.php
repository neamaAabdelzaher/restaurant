

<?php $__env->startSection('title','Add Category'); ?>

<?php $__env->startSection('content'); ?>



<div class="col-sm-12 col-xl-12">
    <h3 class="m-4">Add Category</h3>

    <div class="bg-light  h-100 p-4">
        <form method="post" action="<?php echo e(route('dashboard.categories.store')); ?>" enctype="multipart/form-data" >
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label for="category_name" class="form-label text-dark"  >Category Name</label>
                <input type="text" name="category_name" placeholder="Category Name " class="form-control" value="<?php echo e(old('category_name')); ?>" id="category_name">
                
            </div>
            <?php $__errorArgs = ['category_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-warning"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
       
            
            <button type="submit"  class="btn btn-primary"> Add </button>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.parent', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\restaurant\resources\views/Dashboard/categories/create.blade.php ENDPATH**/ ?>