
<?php $__env->startSection('title','dashboard'); ?>

<?php $__env->startSection('content'); ?>
<p>cats</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.parent', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\restaurant\resources\views/Dashboard/index.blade.php ENDPATH**/ ?>