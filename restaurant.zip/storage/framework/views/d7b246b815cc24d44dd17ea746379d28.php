
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header text-center bg-success text-light"> The Meal</div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <p>
                                <h4>
                                    <strong style="color:rgb(10, 167, 101);">meal category:
                                   </strong> <?php echo e($meal->category->category_name); ?>

                                </h4>
                            </p>
                            <p>
                                <h4>
                                    <strong style="color:rgb(10, 167, 101);">meal name:
                                   </strong> <?php echo e($meal->name); ?>

                                </h4>
                            </p>
                            <p>
                                <h4>
                                    <strong style="color:rgb(10, 167, 101);">meal price:
                                   </strong> <?php echo e($meal->price); ?>

                                </h4>
                            </p>
                            <p>
                                <h4>
                                    <strong style="color:rgb(10, 167, 101);">meal description:
                                   </strong> <?php echo e($meal->description); ?>

                                </h4>
                            </p>
                        </div>
                        <div class="col-md-6">

                    <img src="<?php echo e(asset('assets/dashboard/images/'.$meal->image)); ?>" width="350px" alt="<?php echo e($meal->name); ?>">

                        </div>
                       
                    </div>





                </div>


            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <div class="card-header text-center bg-success text-light">Order Information</div>
                <div class="card-body">
                    <?php if(Auth::check()): ?>
                      
                     <form action="<?php echo e(route('restaurant.store')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <p>
                            
                                <strong style="color:rgb(10, 167, 101);">user name:
                               </strong> <?php echo e(auth()->user()->name); ?>

                            
                        </p>
                        <p>
                            
                                <strong style="color:rgb(10, 167, 101);">user email:
                               </strong> <?php echo e(auth()->user()->email); ?>

                            
                        </p>
                        <p>
                            <input hidden type="number" name="meal_id" value="<?php echo e($meal->id); ?>">
                                <strong style="color:rgb(10, 167, 101);">phone:
                               </strong> <input type="text" class="form-control" value="<?php echo e(old('phone')); ?>"  name="phone" required>

                               <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                               <div class="alert alert-warning"><?php echo e($message); ?></div>
                           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                        </p>
                        <p>
                            
                                <strong style="color:rgb(10, 167, 101);">quantity:
                               </strong> <input type="number" class="form-control" name="quantity" value="1" min="1"  max="100">
                               <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                               <div class="alert alert-warning"><?php echo e($message); ?></div>
                           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                        </p>
                        <p>
                            
                                <strong style="color:rgb(10, 167, 101);">date:
                               </strong> <input type="date" class="form-control" name="date" value="<?php echo e(old('date')); ?>" required>
                               <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                               <div class="alert alert-warning"><?php echo e($message); ?></div>
                           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                        </p>
                        <p>
                            
                                <strong style="color:rgb(10, 167, 101);">time:
                               </strong> <input type="time" class="form-control" name="time" value="<?php echo e(old('time')); ?>" required>
                            
                               <?php $__errorArgs = ['time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                               <div class="alert alert-warning"><?php echo e($message); ?></div>
                           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </p>
                        <p>
                            
                                <strong style="color:rgb(10, 167, 101);">address:
                               </strong> <textarea name="address" id="" class="form-control"><?php echo e(old('address')); ?></textarea>
                               <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                               <div class="alert alert-warning"><?php echo e($message); ?></div>
                           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                        </p>
                        <p class="text-center">
                            
                              
                         <button type="submit"  class="btn btn-success" >Order Now</button>
                            
                        </p>

                     </form>
                      
                       <?php else: ?>
                           
                       <p class="text-center"><a class="btn btn-dark " href="<?php echo e(route('login')); ?>"> please login </a></p>
                    <?php endif; ?>
                    
                </div>

            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\restaurant\resources\views/meal_details.blade.php ENDPATH**/ ?>