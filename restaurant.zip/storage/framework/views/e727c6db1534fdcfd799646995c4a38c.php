<!DOCTYPE html>
<html lang="en">
   <head>
      <!-- basic -->
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <!-- mobile metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="viewport" content="initial-scale=1, maximum-scale=1">
      <!-- site metas -->
      <title><?php echo $__env->yieldContent('title'); ?></title>
      <meta name="keywords" content="">
      <meta name="description" content="">
      <meta name="author" content="">
      <!-- site icon -->
      <link rel="icon" href="<?php echo e(asset('assets/dashboard/images/fevicon.png')); ?>" type="image/png" />
      <!-- bootstrap css -->
      <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/css/bootstrap.min.css')); ?>" />
      <!-- site css -->
      <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/style.css')); ?>" />
      <!-- responsive css -->
      <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/css/responsive.css')); ?>" />
      <!-- color css -->
      <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/css/color_2.css')); ?>" />
      <!-- select bootstrap -->
      <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/css/bootstrap-select.css')); ?>" />
      <!-- scrollbar css -->
      <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/css/perfect-scrollbar.css')); ?>" />
      <!-- custom css -->
      <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/css/custom.css')); ?>" />
      

      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

      <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js')}}"></script>
       <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
      <![endif]-->

      <link rel="stylesheet" href="//cdn.bootcss.com/toastr.js/latest/css/toastr.min.css"> 
      <?php echo $__env->yieldContent('css'); ?>
   </head>
   <body class="dashboard dashboard_2">
      <div class="full_container">
         <div class="inner_container">
            <!-- Sidebar  -->
            <nav id="sidebar">
               <div class="sidebar_blog_1">
                  <div class="sidebar-header">
                     
                  </div>
                  <div class="sidebar_user_info">
                     <div class="icon_setting"></div>
                     <div class="user_profle_side">
                        <div class="user_img"><img class="img-responsive" src="<?php echo e(asset('assets/dashboard/images/layout_img/user_img.jpg')); ?>" alt="#" /></div>
                        <div class="user_info">
                           <h6><?php echo e(Auth::user()->name); ?></h6>
                           <p><span class="online_animation"></span> Online</p>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="sidebar_blog_2">
                  <h4>General</h4>
                  <ul class="list-unstyled components">
                     <li class="active">
                        <a href="#dashboard" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-dashboard yellow_color"></i> <span>Meals</span></a>
                        <ul class="collapse list-unstyled" id="dashboard">
                           <li>
                              <a href="<?php echo e(route('dashboard.meals.index')); ?>"> <span>All Meals</span></a>
                           </li>
                           <li>
                              <a href="<?php echo e(route('dashboard.meals.create')); ?>"> <span>Create Meal</span></a>
                           </li>
                        </ul>
                     </li>
                     
                     <li>
                        <a href="#apps" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-object-group blue2_color"></i> <span>Categories</span></a>
                        <ul class="collapse list-unstyled" id="apps">
                           <li><a href="<?php echo e(route('dashboard.categories.index')); ?>"> <span>All Categories</span></a></li>
                           <li><a href="<?php echo e(route('dashboard.categories.create')); ?>"> <span>Create Category</span></a></li>
                        </ul>
                     </li>
                     <li class="active">
                        <a href="#additional_page" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-clone yellow_color"></i> <span>Orders</span></a>
                        <ul class="collapse list-unstyled" id="additional_page">
                           <li>
                              <a href="<?php echo e(route('dashboard.orders.index')); ?>"> <span> All Orders</span></a>
                           </li>
                         
                        </ul>
                     </li>
                     
               </div>
            </nav>
            <!-- end sidebar -->
            <!-- right content -->
            <div id="content">
               <!-- topbar -->
               <div class="topbar">
                  <nav class="navbar navbar-expand-lg navbar-light">
                     <div class="full">
                        <button type="button" id="sidebarCollapse" class="sidebar_toggle"><i class="fa fa-bars"></i></button>
                        
                <img src="<?php echo e(asset('assets/images/logo.png')); ?>" width="70" height="70" alt="logo">
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">Restaurant</a>

                        <div class="right_topbar">
                           <div class="icon_info">
                              
                              <ul class="user_profile_dd">
                                 <li>
                                    <a class="dropdown-toggle" data-toggle="dropdown"><img class="img-responsive rounded-circle" src="<?php echo e(asset('assets/dashboard/images/layout_img/user_img.jpg')); ?>" alt="#" /><span class="name_user"><?php echo e(Auth::user()->name); ?></span></a>
                                    <div class="dropdown-menu">
                                    
                                       <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('auth.logout')); ?>  <i class="fa fa-sign-out"></i>
                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                   
                                    </div>
                                 </li>
                              </ul>
                           </div>
                        </div>
                     </div>
                  </nav>
               </div>
               <!-- end topbar -->
               <!-- dashboard inner -->
              <?php echo $__env->yieldContent('content'); ?>
               <!-- end dashboard inner -->

               <div class="container-fluid fixed-bottom ">
                <div class="footer mt-5  ">
                   <p class=" text-center">Copyright © 2023 Designed by Neama Abdelzaher  <a href="">ThemeWagon</a>
                   </p>
                </div>
             </div>
            </div>
         </div>
      </div>
      <!-- jQuery -->
      <script src="<?php echo e(asset('assets/dashboard/js/jquery.min.js')); ?>"></script>
      <script src="<?php echo e(asset('assets/dashboard/js/popper.min.js')); ?>"></script>
      <script src="<?php echo e(asset('assets/dashboard/js/bootstrap.min.js')); ?>"></script>
      <!-- wow animation -->
      <script src="<?php echo e(asset('assets/dashboard/js/animate.js')); ?>"></script>
      <!-- select country -->
      <script src="<?php echo e(asset('assets/dashboard/js/bootstrap-select.js')); ?>"></script>
      <!-- owl carousel -->
      <script src="<?php echo e(asset('assets/dashboard/js/owl.carousel.js')); ?>"></script> 
      <!-- chart js -->
      <script src="<?php echo e(asset('assets/dashboard/js/Chart.min.js')); ?>"></script>
      <script src="<?php echo e(asset('assets/dashboard/js/Chart.bundle.min.js')); ?>"></script>
      <script src="<?php echo e(asset('assets/dashboard/js/utils.js')); ?>"></script>
      <script src="<?php echo e(asset('assets/dashboard/js/analyser.js')); ?>"></script>
      <!-- nice scrollbar -->
      <script src="<?php echo e(asset('assets/dashboard/js/perfect-scrollbar.min.js')); ?>"></script>
      <script>
         var ps = new PerfectScrollbar('#sidebar');
      </script>
      <!-- custom js -->
      <script src="<?php echo e(asset('assets/dashboard/js/custom.js')); ?>"></script>
      <script src="<?php echo e(asset('assets/dashboard/js/chart_custom_style2.js')); ?>"></script>
      <script src="//cdn.bootcss.com/jquery/2.2.4/jquery.min.js"></script>
      
    <script src="//cdn.bootcss.com/toastr.js/latest/js/toastr.min.js"></script>
 
    <script>
       <?php if(Session::has('message_id')): ?>
       var type ="<?php echo e(Session::get('alert-type','info')); ?>"
       switch(type){
           case'info':
           toastr.info("<?php echo e(Session::get('message_id')); ?>");
           
           break;
   
            case'success':
           toastr.success("<?php echo e(Session::get('message_id')); ?>");
           break;
   
           case'warning':
           toastr.warning ("<?php echo e(Session::get('message_id')); ?>");
           break;
   
            case'error':
           toastr.error ("<?php echo e(Session::get('message_id')); ?>");
           break;
       }
   
   <?php endif; ?>
   </script>

         <?php echo $__env->yieldContent('js'); ?>

   </body>
</html><?php /**PATH C:\xampp\htdocs\restaurant\resources\views/layouts/parent.blade.php ENDPATH**/ ?>