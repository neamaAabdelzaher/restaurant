
<?php $__env->startSection('title', 'Add Meal'); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-sm-12 col-xl-12">

        <div class="bg-light  h-100 p-4">
        <h3 class="m-4 bg-primary border rounded text-center">Add Meal</h3>

            <form method="post" action="<?php echo e(route('dashboard.meals.store')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                
                <div class="mb-3">
                    <label for="meal_name" class="form-label text-dark">Meal Name</label>
                    <input type="text" name="name" value="<?php echo e(old('name')); ?>" placeholder="Meal Name "
                        class="form-control" id="meal_name">

                </div>
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-warning"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                
                <div class="mb-3">
                    <label for="meal_description" class="form-label text-dark">Meal Description</label>

                    <textarea class="form-control" id="meal_description" name="description" rows="5"><?php echo e(old('description')); ?></textarea>

                </div>
                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-warning"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                
                <div class="mb-3">
                    <label for="meal_price" class="form-label text-dark">Meal Price</label>
                    <input type="number" name="price" value="<?php echo e(old('price')); ?>" placeholder="Meal Price "
                        class="form-control" id="meal_price">

                </div>
                <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-warning"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                


                <div class="form-group">
                    <label for="image">Image</label>
                    <input type="file" class="form-control" id="image" name="image">
                </div>
                <div >
                    <img width="100px" height="100px"  id="imageShow" src="<?php echo e(asset('assets/dashboard/images/No-Image-Placeholder.svg.png')); ?>" alt="meal image">
                </div>
                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-warning"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>



                

                <div class="form-group">
                    <label for="cat_id">Category<span class="text-danger">*</span></label>
                    
                    <div class="controls">
                        <select  name="category_id"  id="cat_id" class="form-group" aria-label="Default select example">
                            <option disabled selected>Select Category</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>" <?php echo e($category->id == old('category_id') ? 'selected' : ''); ?>>
                                    <?php echo e($category->category_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-warning mt-1">
                        <?php echo e($message); ?>

                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>




               <div class="form-group text-center mb-5">
                <button type="submit" class="btn btn-primary"> Add </button>
               </div>
            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script type="text/javascript">
$(document).ready(function() {
    $('input[type="file"]').change(function(e) {
        var reader = new FileReader();

        reader.onload = function(e) {
            $('#imageShow').attr('src', e.target.result);
        };

        reader.readAsDataURL(this.files[0]); // Read the selected image file
    });
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.parent', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\restaurant\resources\views/Dashboard/meals/create.blade.php ENDPATH**/ ?>